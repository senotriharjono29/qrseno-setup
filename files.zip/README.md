# QR Setup & Redirect (qrseno.com/setup/:id)

## Cara jalanin di lokal
```bash
npm install
npm start
```
Buka `http://localhost:3000/setup/123`

## Alur kerja
- **GET /setup/:id** — dicek dulu ke "database" (`data.json`):
  - Belum ada link → tampil form input Google Maps.
  - Sudah ada link → langsung `redirect 302` ke Google Maps usaha itu.
- **POST /setup/:id** — simpan link yang diinput, lalu redirect ke Maps-nya.

## Supaya bisa dipakai di qrseno.com
1. Deploy server ini ke hosting yang support Node.js, misalnya **Railway**, **Render**, atau **VPS** (DigitalOcean/dsb). Vercel/Netlify bisa juga tapi perlu adaptasi ke serverless function (lihat catatan di bawah).
2. Arahkan domain `qrseno.com` (A record / CNAME) ke server tersebut.
3. Generate QR code yang isinya `https://qrseno.com/setup/123`, `.../setup/124`, dst — satu ID per QR/pembeli.

## Soal databasenya
Saat ini pakai file `data.json` — simpel dan cukup untuk testing atau skala kecil (server tetap nyala, disk persisten). Kalau mau lebih aman/scalable:
- **MySQL/Postgres**: ganti `loadDB()`/`saveDB()` dengan query ke tabel `(id, maps_link, created_at)`.
- **Airtable**: pakai Airtable REST API, satu row = satu ID.
- **Google Sheets**: pakai Google Sheets API atau Apps Script sebagai backend — cocok kalau timnya lebih nyaman ngedit lewat spreadsheet.

Kalau kamu deploy ke platform **serverless** (Vercel, Netlify Functions, dsb), file JSON di disk TIDAK akan persisten antar request — di situ wajib pakai database eksternal (MySQL/Airtable/Google Sheets/Supabase, dll), bukan file lokal.

## Reset link (opsional)
Kalau butuh ganti link Maps yang salah, ada endpoint `POST /setup/:id/reset` yang menghapus data lama sehingga form setup muncul lagi.
